#pragma once

struct Vector3
{
	float x, y, z;
};

struct Matrix4x4
{
	float m[4][4];
};